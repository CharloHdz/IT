using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomGenerator : MonoBehaviour
{

    //public GameObject wallPrefab;
    public Vector2 roomSize;
    private Vector2 wallSize = new Vector2(1, 1);
    private int seed;

    private List<Matrix4x4> wallMatricesN;
    private List<Matrix4x4> wallMatricesNB;
    private List<Matrix4x4> wallMatricesNC;
    public Mesh wallMesh;
    //public Mesh wallMeshB;
    //public Mesh wallMeshC;
    public Material wallMaterial0;
    public Material wallMaterial1;

    // Start is called before the first frame update
    void Start()
    {
        createWalls();
        renderwalls();
    }

    // Update is called once per frame
    void Update()
    {
        if (anyChanges()){
            createWalls();
        }

        renderwalls();
    }

    void createWalls(){
        Random.InitState(seed);

        wallMatricesN = new List<Matrix4x4>();
        wallMatricesNB = new List<Matrix4x4>();
        wallMatricesNC = new List<Matrix4x4>();

        int wallCount = Mathf.Max(1, (int)(roomSize.x / wallSize.x));
        float scale = (roomSize.x / wallCount) / wallSize.x;

        for (int i = 0; i < wallCount; i++){

            var t = transform.position + new Vector3(-roomSize.x / 2 + wallSize.x * scale / 2 + i * scale * wallSize.x, 0, -roomSize.y / 2);
            var r = transform.rotation;
            var s = new Vector3(scale, 1, 1);

            var mat = Matrix4x4.TRS(t, r, s);

            var rand = Random.Range(0, 3);
            if (rand < 1){
                wallMatricesN.Add(mat);
            } else if (rand < 2){
                wallMatricesNB.Add(mat);
            } else{
                wallMatricesNC.Add(mat);
            }
        }

    }

    void renderwalls(){
        if (wallMatricesN != null){
            Graphics.DrawMeshInstanced(wallMesh, 0, wallMaterial0, wallMatricesN.ToArray(), wallMatricesN.Count);
            //Graphics.DrawMeshInstanced(wallMesh, 1, wallMaterial1, wallMatricesN.ToArray(), wallMatricesN.Count);
        }
    }

    bool anyChanges(){
        if (wallMatricesN == null || wallMatricesNB == null || wallMatricesNC == null)
            return true;

        if (wallMatricesN.Count != transform.childCount / 2)
            return true;

        if (wallMatricesNB.Count != transform.childCount / 2)
            return true;

        if (wallMatricesNC.Count != transform.childCount / 2)
            return true;

        return false;
    }

    void OnDrawGizmosSelected(){
        Gizmos.color = Color.white;
        Gizmos.DrawWireCube(transform.position, new Vector3(roomSize.x, 2f, roomSize.y));
    }
}
